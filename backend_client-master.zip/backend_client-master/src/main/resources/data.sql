insert into client(name,email) values ('Amilda Juca','amilda.juca@gmail.com');
insert into client(name,email) values ('Bruna Mouse','bruna.mouse@gmail.com');
insert into client(name,email) values ('Carlos Silva','carlos.silva@gmail.com');